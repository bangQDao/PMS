var searchData=
[
  ['myclass',['myclass',['../structmyclass.html',1,'']]],
  ['myclass2',['myclass2',['../structmyclass2.html',1,'']]]
];
