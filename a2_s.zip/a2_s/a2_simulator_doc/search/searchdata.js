var indexSectionsWithContent =
{
  0: "abcefgilmopqrstvwxyz~",
  1: "ampqrst",
  2: "agst",
  3: "aimst",
  4: "cegmoqrsty~",
  5: "abcfglmoprstvwxyz",
  6: "ag",
  7: "ab",
  8: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Pages"
};

