var indexSectionsWithContent =
{
  0: "acefgilmstv",
  1: "f",
  2: "acimt",
  3: "cefglmt",
  4: "msv",
  5: "ae",
  6: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Pages"
};

