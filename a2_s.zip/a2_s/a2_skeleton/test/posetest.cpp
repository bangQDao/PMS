#include "gtest/gtest.h"
#include <iostream>

#include <vector>

// Student defined libraries, for instance
//#include "flightplanner.h"

#include "../dep/include/types.h"
#include "../dep/include/tf.h"
#include "../tf2.h"
using namespace std;
using geometry_msgs::Pose;
using geometry_msgs::Point;
using geometry_msgs::RangeBearingStamped;
using std::vector;
using namespace tf;

//==================== UNIT TEST START ====================//

TEST(PoseTest, LocalToGlobal)
{
    flightControl fc;
    Pose aircraft;
    aircraft.position = {0,0,0};
    aircraft.orientation = yawToQuaternion(0.785398);

    {
        Point bogie = {3171.34,-4574.67,0};
        RangeBearingStamped rb = {5566.41,4.53316,0};
        Point bogieComputed = fc.local2Global(rb,aircraft);
        EXPECT_NEAR(bogie.x,bogieComputed.x,0.5);
        EXPECT_NEAR(bogie.y,bogieComputed.y,0.5);
    }

    {
        Point bogie = {-3288.52,-2516.65,0};
        RangeBearingStamped rb = {4141,3.0094,0};
        Point bogieComputed = fc.local2Global(rb,aircraft);

        EXPECT_NEAR(bogie.x,bogieComputed.x,0.5);
        EXPECT_NEAR(bogie.y,bogieComputed.y,0.5);
    }

}

TEST(PoseTest, GlobalToLocal)
{
    Pose aircraft;
    flightControl fc;
    aircraft.position = {0,0,0};
    aircraft.orientation = tf::yawToQuaternion(0.785398);

    {
        Point bogie = {3171.34,-4574.67,0};
        RangeBearingStamped rb = {5566.41,-1.750020322,0};

        RangeBearingStamped rbComputed = fc.global2local(bogie,aircraft);

        EXPECT_NEAR(rb.range,rbComputed.range,0.5);
        EXPECT_NEAR(rb.bearing,rbComputed.bearing,0.5);
    }

    {
        Point bogie = {-3288.52,-2516.65,0};
        RangeBearingStamped rb = {4141,3.0094,0};

        RangeBearingStamped rbComputed = fc.global2local(bogie,aircraft);

        EXPECT_NEAR(rb.range,rbComputed.range,0.5);
        EXPECT_NEAR(rb.bearing,rbComputed.bearing,0.5);

    }
}


int main(int argc, char **argv)
{
  ::testing::InitGoogleTest(&argc, argv);

  return RUN_ALL_TESTS();
}
