#include "gtest/gtest.h"
#include <iostream>
#include <vector>

// Student defined libraries, for instance
//#include "flightplanner.h"

#include "../dep/include/types.h"
#include "../dep/include/tf.h"
#include "../tf2.h"
#include "../dep/include/simulator.h"

#include <algorithm>
using namespace std;
using geometry_msgs::Pose;
using geometry_msgs::Point;
using geometry_msgs::RangeBearingStamped;
using std::vector;
using namespace tf;
using namespace simulator;

//==================== UNIT TEST START ====================//


TEST(AssociationTest, RangeBearingToBogie)
{
    Pose aircraft;
    aircraft.position = {0,0,0};
    aircraft.orientation = yawToQuaternion(0.785398);
    {

}
}

TEST(AssociationTest, RangeVelocityToBogie)
{



}


int main(int argc, char **argv)
{
  ::testing::InitGoogleTest(&argc, argv);

  return RUN_ALL_TESTS();
}
