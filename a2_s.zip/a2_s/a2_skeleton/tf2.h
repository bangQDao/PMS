#ifndef TF2_H
#define TF2_H
#include "simulator.h"
#include "types.h"
#include <vector>
#include <utility>
using namespace simulator;
using geometry_msgs::Pose;
using geometry_msgs::Point;
using geometry_msgs::RangeBearingStamped;
using std::pair;
using std::vector;
using namespace simulator;
typedef pair<double, unsigned int> EdgeInfo;
typedef vector<vector<EdgeInfo> > AdjacencyList;
class flightControl {
    /*!
     * \brief _sim Shared pointer for simulator library
     * to use for other methods
     */
    std::shared_ptr<Simulator> _sim;

    /*!
     * \brief _mode Set the aircraft to moving specifications
     * \returns int
     */
    int _mode;

    /*!
     * \brief omega_MAX Maximum angular velocity at minimum velocity
     */
    const double omega_MAX = Simulator::G_MAX * 9.81 / Simulator::V_TERM;

    /*!
     * \brief Return the closest predicted location of bogie
     * at minimum time that aircarf needs to moving to
     */
    Point _nextPositionConfirm;
    /*!
     * \brief 2 points of one bogie at 2 different time
     * to calculate the angular vector
     *
     * Combine with the bogie's velocity, to determine next location of it in 10 seconds with 1 second interval
     */
    Point p1,p2;
public:
    /*!
     * \brief Constructor use for unit test
     */
    flightControl();

    /*!
     * \brief flightControl Constructor use for simulation
     * \param sim
     * to receive returned values from simulator library
     * write a share pointer to private member
     */
    flightControl(std::shared_ptr<Simulator> sim);

    /*!
     * \brief controlAircraft Control the aircraft
     *
     * Each mode control will depends on the future location of bogie
     * with moving straight at 1000m/s and turning at 50m/s at maximum angular velocity of 6G
     */
    void controlAircraft();

    /*!
     * \brief goalPredict Predict future location of bogie
     */
    void goalPredict();

    /**
         * @brief compute the range and bearig (polar coordinates) of bogie) relative to aicrraft pose suppplied
         * @param globalBogie - x,y location of bogie in the reference frame of (base station)
         * @param aircraft - Pose relative to map origin (base station)
         * @return rangeBearing - (polar coordinates of bogie) relative to the aircraft Pose suppplied
         */

    RangeBearingStamped global2local(Point bogie, Pose aircraft);
    /**
         * @brief Determines time to impact (time to reach each goal)
         * @note To reach any of the goals from the origin you can either turn (at max permisable angular velocity
         * OMEGA MAX while having lowest liner velocity V_TERM) or go straight (at maximum possible linear
         * velocity V_MAX. Whilst obeying OMEGA*V<= 6G.</br>
         * Therefore, for each goal the computation for time to impact has to take into account the distance
         * and angle for each goal from the origin pose.
         *
         * @param origin for the search
         * @return time to impact for each goal(s) (this vector has same size as the poses supplied)
         * each element is time to impact for the respective goal
         */
    double timeToImpact(Pose pose,Point nextPoint);

    /**
     * @brief Control aircraft's orientation and velocity
     */
    void movingToPredictedPosition();
    /**
     * @brief Compute x,y location of bogie in the reference frame of base station (which is at 0,0)
     * @param rangeBearing - (polar coordinates) of bogie, obtained from the Pose suppplied
     * @param aircraft - Pose where the readings were obtained, this pose in relative to map origin (base station)
     * @return location of bogie relative to map origin (base station)
     */
    Point local2Global(RangeBearingStamped rangeBearing, Pose aircraft);

};

#endif // TF2_H
