#include "tf2.h"
#include "tf.h"
#include <cmath> // for trig operations
#include "simulator.h"
#include <iostream>
#include <mutex>
using namespace simulator;
using std::vector;
using std::pair;
using geometry_msgs::Pose;
using geometry_msgs::Point;
using std::pair;
std::mutex mtx;
std::mutex mtx2;
using namespace std;
flightControl::flightControl() {

}
flightControl::flightControl(const std::shared_ptr<Simulator> sim) : _sim(sim) {

}

void flightControl::movingToPredictedPosition() {

    Pose pose = _sim->getFriendlyPose();
    RangeBearingStamped FriendlytoPredict =  global2local(_nextPositionConfirm, pose);
    if (FriendlytoPredict.bearing <= M_PI && FriendlytoPredict.bearing > 2 * M_PI / 180 || FriendlytoPredict.bearing <= -M_PI ) {
      mtx.lock();
      //CW
      _mode = 1; mtx.unlock();
    }
    if (FriendlytoPredict.bearing > -M_PI && FriendlytoPredict.bearing < -2 * M_PI / 180) {

      mtx.lock(); _mode = 2; mtx.unlock();
    }//CCW

    if (FriendlytoPredict.bearing <= 2 * M_PI / 180 && FriendlytoPredict.bearing >= -2 * M_PI / 180) {
      mtx.lock();
      _mode = 3;
      mtx.unlock();
    }
}

void flightControl::controlAircraft() {
  if (_mode == 1) {
    mtx.lock();
    _sim ->controlFriendly(50, omega_MAX);
    mtx.unlock();

  }
  if (_mode == 2) {
    mtx.lock();
    _sim ->controlFriendly(50, -omega_MAX);
    mtx.unlock();
  }
  if (_mode == 3) {
    mtx.lock();
    _sim ->controlFriendly(1000, 0);
    mtx.unlock();
  }
}
Point flightControl::local2Global(RangeBearingStamped rangeBearing, Pose aircraft)
{
    Point p;
    p.x = rangeBearing.range * cos(rangeBearing.bearing + tf::quaternionToYaw(aircraft.orientation)) + aircraft.position.x;
    p.y = rangeBearing.range * sin(rangeBearing.bearing + tf::quaternionToYaw(aircraft.orientation)) + aircraft.position.y;
    return p;

}

RangeBearingStamped flightControl::global2local(Point bogie, Pose aircraft) {
  double delta_x;
  double delta_y;
  double angle;
  mtx.lock();
  delta_x = bogie.x - aircraft.position.x;
  delta_y = bogie.y - aircraft.position.y;
  double angle_fix = atan2(delta_y, delta_x);
  if(angle_fix<0) angle_fix += 2 * M_PI ;
  angle = angle_fix - tf::quaternionToYaw(aircraft.orientation);
  while (angle > M_PI)
    angle = angle - (2 * M_PI);
  while (angle < -M_PI)
    angle = angle + (2 * M_PI);
  mtx.unlock();
  double rangeAirtoBogies;
  rangeAirtoBogies = sqrt(pow(delta_x, 2) + pow(delta_y, 2));
  RangeBearingStamped rbstamped = {0, 0, 0};
  rbstamped.range = rangeAirtoBogies;
  rbstamped.bearing = angle;
  return rbstamped;
}

double flightControl::timeToImpact(Pose pose, Point nextpoint) {
  vector<double> times;
  RangeBearingStamped to_goals =  global2local(nextpoint, pose);
  double time;
  double adjust_bearing = to_goals.bearing;
  if (adjust_bearing * 180 / M_PI > 180 || adjust_bearing * 180 / M_PI < -180) {
    adjust_bearing = (360 - abs(to_goals.bearing) * 180 / M_PI) * M_PI / 180;
  }
  else {
    adjust_bearing = abs(to_goals.bearing);
  }
  time = to_goals.range / Simulator::V_MAX + adjust_bearing / omega_MAX;
  return time;
}

void flightControl::goalPredict() {
    std::vector<RangeVelocityStamped> Velocity = _sim->rangeVelocityToBogiesFromBase();
    mtx2.lock();
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    Pose pose = _sim->getFriendlyPose();
    std::vector<RangeBearingStamped> rangeBearingStampedVec = _sim->rangeBearingToBogiesFromFriendly();
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    Pose pose1 = _sim->getFriendlyPose();
    std::vector<RangeBearingStamped> rangeBearingStampedVec1 = _sim->rangeBearingToBogiesFromFriendly();
    mtx2.unlock();
    mtx.lock();
    p1.x = rangeBearingStampedVec.at(0).range * cos(rangeBearingStampedVec.at(0).bearing + tf::quaternionToYaw(pose.orientation)) + pose.position.x;
    p1.y = rangeBearingStampedVec.at(0).range * sin(rangeBearingStampedVec.at(0).bearing + tf::quaternionToYaw(pose.orientation)) + pose.position.y;
    mtx.unlock();
    mtx.lock();
    p2.x = rangeBearingStampedVec1.at(0).range * cos(rangeBearingStampedVec1.at(0).bearing + tf::quaternionToYaw(pose1.orientation)) + pose1.position.x;
    p2.y = rangeBearingStampedVec1.at(0).range * sin(rangeBearingStampedVec1.at(0).bearing + tf::quaternionToYaw(pose1.orientation)) + pose1.position.y;
    mtx.unlock();
    mtx.lock();
    double angle1 = atan2((p2.y - p1.y), (p2.x - p1.x)); mtx.unlock();
    for (int i = 1; i < 10; i++) {
      Point nextPosition;
      nextPosition.x = p2.x + cos(angle1) * Velocity.at(0).velocity * i;
      nextPosition.y = p2.y + sin(angle1) * Velocity.at(0).velocity * i;
      double timeFromFriendly = timeToImpact(pose1, nextPosition);
      if (timeFromFriendly - i<0.2) {
        _nextPositionConfirm = nextPosition;
        break;
      }
    }
  }



