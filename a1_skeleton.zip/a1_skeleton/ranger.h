#ifndef RANGER_H
#define RANGER_H

#include <string>
#include <chrono>
#include <random>
#include <thread>

#include "rangerinterface.h"
#include "constant.h"
using namespace std;

class Ranger: public RangerInterface
{

public:
  //Default constructor should set all sensor attributes to a default value
Ranger();

vector<double> generateData();

unsigned int getAngularResolution(void);

ranger::SensorPose getSensorPose(void);

unsigned int getFieldOfView(void);

double getMaxRange(void);
double getMinRange(void);

ranger::SensingMethod getSensingMethod(void);

bool setAngularResolution(unsigned int resolution);

bool setSensorPose(ranger::SensorPose pose);

bool setFieldOfView(unsigned int fov);
string getModel();

int getAngularOffset(void);
virtual int getNumberOfSample() = 0;
bool setAngularOffset(int offset);
void pause();

public:
string ModelName;
vector<double> dataRead;
unsigned int angularRes;
int sensorOffset;
unsigned int fieldOfView;
int numberOfSamples;
double maxDistance;
double minDistance;
ranger::SensingMethod SMethod;
ranger::SensorPose SPose;

};

#endif // RANGER_H
