#include"rangerfusion.h"

/* Constructor generate all rangers */
RangerFusion::RangerFusion(std::vector<RangerInterface*> rangers)
{
    Rangers_ = rangers;
}
/* Vector to store all rangers */
std::vector<RangerInterface*> RangerFusion::getRangers()
{
    return Rangers_;
}

/* Vector to populate raw range data */
vector<vector<double> > RangerFusion::getRawRangeData()
{
    rawRangeData_.resize(Rangers_.size());
    for(int i = 0;i<rawRangeData_.size();i++)
    {
        rawRangeData_[i]=(*Rangers_[i]).generateData();
    }
    return rawRangeData_;
}

/* Function set up cells */
void RangerFusion::setCells(std::vector<Cell*> cells)
{
    xCells = cells;
}

/* Vector to store all cells */
vector<Cell*> RangerFusion::getCells()
{
    return xCells;
}

/* Vector to get and store 2 sonars offset */
vector<double> RangerFusion::getSonarOffset()
{
    vector<double> vec_offset;
    double var_offset;
    for(auto i : getRangers())
    {
        var_offset = i -> getSensorPose().theta;
        if( i->getFieldOfView() == FusionSonarFieldOfView )
            vec_offset.push_back(var_offset);
    }
    for(int i = 0; i <  vec_offset.size(); i++)
    {
        sonar1stOffset =  vec_offset[0];
        sonar2ndOffset =  vec_offset[1];
    }
    return vec_offset;
}

/* Vector to get and store 2 sonars pose */
vector<ranger::SensorPose> RangerFusion::getSensorPoses(){
    vector<ranger::SensorPose> sonarPoses;
    ranger::SensorPose sonarPose;
    for(auto m : getRangers())
    {
        sonarPose = m -> getSensorPose();
        if( m->getFieldOfView() == FusionSonarFieldOfView )
            sonarPoses.push_back(sonarPose);
    }

    for(int m = 0; m <  sonarPoses.size(); m++)
    {
        sonar1stPose =  sonarPoses[0];
        sonar2ndPose =  sonarPoses[1];
    }
    return sonarPoses;
}


vector<ranger::SensorPose> RangerFusion::getSonarPose(){
    vector<ranger::SensorPose> sonarPoses = getSensorPoses();
    vector<double> sonarResponse = getSonarResponse();
          for(int i = 0; i < sonarResponse.size(); i++)
    {
        ranger::SensorPose sonarPose1,sonarPose2;
        sonarPose1.x = sonarResponse[i]*cos((90+sonarPoses[i].theta - FusionFieldOfView/2)*Pi/180);
        sonarPose1.y = sonarResponse[i]*sin((90+sonarPoses[0].theta - FusionFieldOfView/2)*Pi/180);

        sonarPose2.x = sonarResponse[i]*cos((90+sonarPoses[i].theta + FusionFieldOfView/2)*Pi/180);
        sonarPose2.y = sonarResponse[i]*sin((90+sonarPoses[0].theta + FusionFieldOfView/2)*Pi/180);
        sonarPoses.push_back(sonarPose1);
        sonarPoses.push_back(sonarPose2);
    }
    return sonarPoses;
}
/* Default Function for Laser Resolution */
double RangerFusion::getAngularResolution()
{
    for( auto m : getRangers())
    {
        if( m -> getFieldOfView() == FusionLaserFieldOfView)
        laserRes = m -> getAngularResolution();
    }
    return laserRes;
}

/* Function returns area covers by 2 sonars */
double RangerFusion::getScanningArea()
{
    double tempArea;
    vector<double> sonarResponse = getSonarResponse();
    double sonarArea = 0;
    getSonarResponse();
    vector<ranger::SensorPose> sonarPose = getSonarPose();
    for (auto i : sonarResponse)
    {
        tempArea += (i*i*Pi*FusionFieldOfView)/FusionAngleRange;

    }
    /* Condition in case 2 sonars duplicate same area */
    if (abs(sonarPose[0].theta-sonarPose[1].theta) >= 20)
    {
        sonarArea = tempArea;
    }

    else
    {
        double smallerSonar = *min_element(sonarResponse.begin(), sonarResponse.end()); //find the smallest cone side
        double angleDuplicate = abs(abs(sonarPose[0].theta-sonarPose[1].theta)-FusionFieldOfView);                            //the angle between 2 dupplicate cone
        sonarArea = tempArea - (pow(smallerSonar,2)*angleDuplicate*Pi )/FusionAngleRange;
    }

    rawConeCovered = sonarArea;
    return rawConeCovered;
}

/* Vector for obtaining sonar response */
vector<double> RangerFusion::getSonarResponse()
{
    vector<double> sonarResponse;
     for(int m = 0; m < rawRangeData_.size();m++)
    {
        if(rawRangeData_[m].size()<2)
        {
            for(int n=0; n < rawRangeData_[m].size(); n++)
                sonarResponse.push_back(rawRangeData_[m][n]);
        }
    }
    return sonarResponse;
}


/* Vector for obtaining laser response */
std::vector<double> RangerFusion::getLaserResponse()
{
    vector<double> laserResponse;
    for(int i = 0; i < rawRangeData_.size();i++)
    {
        if(rawRangeData_[i].size()>2)
        {
            for(int j=0; j < rawRangeData_[i].size(); j++)
                laserResponse.push_back(rawRangeData_[i][j]);
        }
    }
    return laserResponse;
}

/* Function set up cell */
double RangerFusion::setCellside(double cellside)
{
    for(auto i = xCells.begin();i != xCells.end();i++)
    {
        (*i)->setSide(cellside);
        cellSide_= cellside;
    }
}

/* Vector checks and stores laser pose */
vector<ranger::SensorPose> RangerFusion::getLaserPose(){
    vector<ranger::SensorPose> vec_laserPose;
    ranger::SensorPose laserPose;

    for(auto i : getRangers())
    {
        if(i->getFieldOfView()== FusionLaserFieldOfView)
            laserPose = i -> getSensorPose();

    }
    double laserResolution = getAngularResolution();
    vector<double> laserResponse = getLaserResponse();

    for(int i = 0; i < getLaserResponse().size(); i++)
    {

        if(i*laserResolution +laserPose.theta == 90)
        {
            laserPose.x = 0;
        }
        else if( i*laserResolution + laserPose.theta == 0  )
        {
            laserPose.x = laserResponse[i];
        }
        else if(i*laserResolution + laserPose.theta == 180)
        {
            laserPose.x = -laserResponse[i];
        }
        else
        {
            laserPose.x = (laserResponse[i])*cos((i*laserResolution+laserPose.theta)*Pi/180);
        }

        laserPose.y = laserResponse[i]*sin((i*laserResolution + laserPose.theta)*Pi/180); //convert to radians

        vec_laserPose.push_back(laserPose);
    }
    return vec_laserPose;

}

/* Vector stores 2 points of x coordinate of cell */
vector<double> RangerFusion::getX(double x, double cellsize)
{
    vector<double> vec_cellX;
    double  x1, x2;
    if( x >= 0)
    {
        x1 = x - 0.5*cellsize;
        x2 = x + 0.5*cellsize;
    }

    if( x < 0)
    {
        x1 = x + 0.5*cellsize;
        x2 = x - 0.5*cellsize;
    }
    vec_cellX = {x1, x2};
    return vec_cellX;
}

/* Vector stores 2 points of y coordinate of cell */
vector<double> RangerFusion::getY(double y, double cellsize)
{
    vector<double> vec_cellY;
    double  y1, y2;
    if(y>= 0)
    {
    y1 = y - 0.5*cellsize;
    y2 = y + 0.5*cellsize;
    }

    if(y<0)
    {
        y1 = y + 0.5*cellsize;
        y2 = y - 0.5*cellsize;
    }
    vec_cellY = {y1, y2};

    return vec_cellY;
}

/* Fusion result between laser and cells */
vector<cell::State> RangerFusion::laserFusion(double xCenterCell, double yCenterCell, double cellside, vector<double>vec_cellX, vector<double>vec_cellY, vector<double>Ranger,
                               vector<ranger::SensorPose> laserPosess)
{
   getX(xCenterCell, cellside);
   getY(yCenterCell, cellside);
   vector<cell::State> stateByLaser;
   int temp=0;
   for(int i = 0; i < Ranger.size(); i++)
   {
       double laserBeam = laserPosess[i].y/laserPosess[i].x;
       double cell1Diagonal = vec_cellY[0] / (vec_cellX[0] + cellside);
       double cell2Diagonal = vec_cellY[1] / (vec_cellX[1] - cellside);

       if (Ranger.size() == getLaserResponse().size() && yCenterCell-cellside/2<laserPosess[Ranger.size()-1].x )
       {
           temp = 0;
       }
       else
       {
           if ((laserPosess[i].x>0 || laserPosess[i].x<0)  && laserPosess[i].y > 0)
           {
               if(((laserPosess[i].x > 0 && laserPosess[i].y > 0 && laserPosess[i].x > vec_cellX[0] && laserPosess[i].y > vec_cellY[0] && laserBeam > cell1Diagonal && laserBeam < cell2Diagonal)
                   || (laserPosess[i].x < 0 && laserPosess[i].y > 0 && laserPosess[i].x < vec_cellX[0] && laserPosess[i].y > vec_cellY[0] && laserBeam < cell1Diagonal && laserBeam > cell2Diagonal))
                   &&temp==0)
               {
                   temp = 1;
               }
               if (((laserPosess[i].x>0 && laserPosess[i].y> 0 && laserPosess[i].x > vec_cellX[0] && laserPosess[i].x < vec_cellX[1] && laserPosess[i].y > vec_cellY[0] && laserPosess[i].y < vec_cellY[1])
                   || (laserPosess[i].x<0 &&laserPosess[i].y > 0 && laserPosess[i].x < vec_cellX[0] && laserPosess[i].x > vec_cellX[1] && laserPosess[i].y > vec_cellY[0] && laserPosess[i].y < vec_cellY[1] ))
                   &&temp==1)
               {
                   temp = 2;
               }
           }

           if((laserPosess[i].x==0) && laserPosess[i].y > 0)
           {

               if(laserPosess[i].y >= vec_cellY[1] || laserPosess[i].y >= vec_cellY[0]
                   &&temp == 0)
               {
                   temp = 1;
               }

               if ( (laserPosess[i].y <= vec_cellY[1]) || ((laserPosess[i].y <= vec_cellY[0]))
                   &&temp==1)
               {
                   temp = 2;
               }
           }

           if(laserPosess[i].y==0)
           {
               if(laserPosess[i].x>0)
               {

                   if(laserPosess[i].x>vec_cellX[0] && temp ==0)
                       temp=1;
                   if(laserPosess[i].x>vec_cellX[0] && laserPosess[i].x<vec_cellX[1]&&temp==1)
                       temp=2;
               }

               if(laserPosess[i].x<0)
               {

                   if(laserPosess[i].x<vec_cellX[1])
                       temp=1;
                   if(laserPosess[i].x<vec_cellX[0] && laserPosess[i].x>vec_cellX[1] &&temp==1)
                   {
                       temp=2;
                   }
               }
           }
       }

   }

   if (temp == 0)
   {
       stateByLaser.push_back(cell::UNKNOWN);
   }
   if (temp == 1)
   {
       stateByLaser.push_back(cell::FREE);
   }
   if (temp == 2)
   {
       stateByLaser.push_back(cell::OCCUPIED);
   }
   return stateByLaser;
}

/* Fusion result between sonar and cells */
vector<cell::State> RangerFusion::SonarFusion(double xCenterCell, double yCenterCell, double cellside)
{
    vector<cell::State> firstFuse;
    vector<cell::State> secondFuse;
    vector<cell::State> finalSonarFuse;
/* Check state between sonar side line and cell */
    firstFuse = laserFusion(xCenterCell, yCenterCell, cellside,  getX(xCenterCell, cellside), getY(yCenterCell, cellside),
                                getSonarResponse(), getSonarPose());
    vector<double> cellXget = getX(xCenterCell, cellside);
    vector<double> cellYget = getY(yCenterCell, cellside);
    vector<ranger::SensorPose> sensorPoses = getSonarPose();
    vector<double> sonar_Response = getSonarResponse();

    double cell1Diagonal = cellYget[0] / (cellXget[0] + cellside);
    double cell2Diagonal = cellYget[1] / (cellXget[1]- cellside);
    int temp = 0;
    for(int i = 0; i < sonar_Response.size(); i++)
    {
        double sonarLine1 = sensorPoses[2*i].y / sensorPoses[2*i].x;
        double sonarLine2 = sensorPoses[2*i+1].y / sensorPoses[2*i+1].x;


        double cellOriDistance = sqrt(pow(xCenterCell,2) +pow(yCenterCell,2));
        double halfCellDiagonal = 1.41*cellside/2;
        /*Cell line insinde Sonar */
            if((sonarLine1>=0 && sonarLine2>=0 && cell1Diagonal > sonarLine1 && cell2Diagonal < sonarLine2) || (sonarLine1<0 && sonarLine2<0 && cell1Diagonal < sonarLine1 && cell2Diagonal > sonarLine2)
                || (sonarLine1 > 0 && sonarLine2 <0 && cell1Diagonal > sonarLine1 && cell2Diagonal > sonarLine2) || (sonarLine1 < 0 && sonarLine2 > 0 && cell1Diagonal < sonarLine1 && cell2Diagonal < sonarLine2)
                &&temp==0)
            {
                temp=1;
            }
            /*Check cell occupied */
            if ((sonar_Response[i]+ halfCellDiagonal <= cellOriDistance) && temp ==1)
            {
                temp = 2;
            }
    }

    if(temp==0)
    {
        secondFuse.push_back(cell::UNKNOWN);
    }
    if(temp==1)
    {
        secondFuse.push_back(cell::FREE);
    }

    if(temp==2)
    {
        secondFuse.push_back(cell::OCCUPIED);
    }

    for(int i = 0; i < firstFuse.size(); i++)
    {
        if((firstFuse[i]==0 && secondFuse[i]==0) || (firstFuse[i]==1 && secondFuse[i]==1) ||(firstFuse[i]==-1 && secondFuse[i]==-1))
        {
            finalSonarFuse.push_back(firstFuse.at(i));
        }

        else if((firstFuse[i]==0 && secondFuse[i]==1) || (firstFuse[i]==1 && secondFuse[i]==0))
        {
            finalSonarFuse.push_back(cell::FREE);
        }

        else if((firstFuse[i]==-1 && secondFuse[i]==0) || (firstFuse[i]==0 || secondFuse[i]==-1) || (firstFuse[i]==1 || secondFuse[i]==-1) ||(firstFuse[i]==-1 || secondFuse[i]==1))
        {
            finalSonarFuse.push_back(cell::OCCUPIED);
        }
        else
            finalSonarFuse.push_back(cell::UNKNOWN);
    }
    return finalSonarFuse;
}

void RangerFusion::grabAndFuseData()
{
   double x, y;
   dataRead = getRawRangeData();
   getRangers();
   getAngularResolution();
   setCells(xCells);
   setCellside(cellSide_);

   for (auto k = xCells.begin();k != xCells.end(); k++ ) //Return the state for each cell
   {
           (*k)->getCentre(x,y);
           (*k)->setSide(cellSide_);

           vector<cell::State> sonar_Fusion= SonarFusion(x, y, cellSide_);
           vector<cell::State> laser_Fusion= laserFusion(x,y,(*k)->getSide(), getX( x, (*k)->getSide()),
                getX( y, (*k)->getSide()), getLaserResponse(), getSonarPose());

           vector<cell::State> finalResult;
           for(int i = 0; i < sonar_Fusion.size(); i ++)
           {
               if((sonar_Fusion[i]==0 && laser_Fusion[i] == 0) || (sonar_Fusion[i]==0 && laser_Fusion[i] == 1) || (sonar_Fusion[i]==-1 && laser_Fusion[i] == -1))
               {
                   finalResult.push_back(sonar_Fusion[i]);
               }
               if((sonar_Fusion[i]== 0 && laser_Fusion[i]==1 ) || (sonar_Fusion[i]== 1 && laser_Fusion[i]== 0))
               {
                   finalResult.push_back(cell::FREE);
               }
               if((sonar_Fusion[i]== 0 && laser_Fusion[i]== -1 ) || (sonar_Fusion[i]== -1 && laser_Fusion[i]== 0)||
                    (sonar_Fusion[i]== -1 && laser_Fusion[i]==1 ) || (sonar_Fusion[i]== 1 && laser_Fusion[i]== -1))
               {
                   finalResult.push_back(cell::OCCUPIED);
               }

           }
           for( auto i : finalResult)
           {
               (*k) -> setState(i);
           }
   }
}

vector<vector<double>> RangerFusion::printRawData()
{
    return rawRangeData_;
}
