#ifndef CONSTANT_H
#define CONSTANT_H
#include<string>
using namespace std;
/* Ranger Base Specs */
const double rangerMean = 5;
const double rangerStdev = 6;
const int angularResDef = 10;
const int angleOffsetDef = 0;
const int sampleInterval = 1000; /* 1000ms */
const int minAngle = 10;
const int maxAngle = 30;
const int offsetMax = 360;
const int offsetMin = -360;

/* Laser specs */
const string LaserModel = "SICK-XL";
const int LaserFieldOfView = 180;
const int LaserAngularResolutionMin = 10;
const int LaserAngularResolutionMax = 30;
const double LaserMaxDistance = 8.0;
const double LaserMinDistance = 0.2;

/* Sonar specs */
const string SonarModel = "SN-001";
const int SonarFieldOfView = 20;
const double SonarMaxDistance = 10.0;
const double SonarMinDistance = 0.2;

/* Ranger Fusion Specs */
const double Pi = 2 * acos(0);
const int FusionFieldOfView = 20;
const int FusionAngleRange= 180;
const int FusionLaserFieldOfView = LaserFieldOfView;
const int FusionSonarFieldOfView = SonarFieldOfView;
#endif
