#include "sonar.h"

Sonar::Sonar()

{
    ModelName = (SonarModel);
    maxDistance = (SonarMaxDistance);
    minDistance = (SonarMinDistance);
    fieldOfView = (SonarFieldOfView);
    sensorOffset = (0);
    SMethod = (ranger::CONE);
}

int Sonar::getNumberOfSample()
{
    numberOfSamples = 1;
    return numberOfSamples;
}

Sonar::~Sonar()
{

}

