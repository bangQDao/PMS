var searchData=
[
  ['map_5fsize_0',['MAP_SIZE',['../namespacecell.html#a2bba1bb42f220c78e17a316c7e7fe5d6',1,'cell']]]
];
