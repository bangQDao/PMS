var searchData=
[
  ['perimeter_0',['perimeter',['../class_cell.html#af02495b8e758ee82478134fd491f3e13',1,'Cell']]]
];
