var searchData=
[
  ['ranger_0',['ranger',['../namespaceranger.html',1,'']]]
];
