var searchData=
[
  ['default_5fcell_5fsize_0',['DEFAULT_CELL_SIZE',['../namespacecell.html#a6515189a47fa6c3bed40b768bdec7a39',1,'cell']]]
];
