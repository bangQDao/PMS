var searchData=
[
  ['getangularresolution_0',['getAngularResolution',['../class_ranger.html#a95b5013ae191d1e19b93fab002306718',1,'Ranger::getAngularResolution()'],['../class_ranger_interface.html#a37d4f89daffa8b2708dfc11034893552',1,'RangerInterface::getAngularResolution()']]],
  ['getcentre_1',['getCentre',['../class_cell.html#a1087822ba50d7afea999824cca8cc1f4',1,'Cell']]],
  ['getfieldofview_2',['getFieldOfView',['../class_ranger.html#a4bca7dce56b7959257d90b1f30bf0271',1,'Ranger::getFieldOfView()'],['../class_ranger_interface.html#a18716da6932402b8dda75f682be6f06c',1,'RangerInterface::getFieldOfView()']]],
  ['getmaxrange_3',['getMaxRange',['../class_ranger.html#aba5e81260e55089d9ff869051156a722',1,'Ranger::getMaxRange()'],['../class_ranger_interface.html#a0bb29a41de5767c99081002c0590c186',1,'RangerInterface::getMaxRange()']]],
  ['getminrange_4',['getMinRange',['../class_ranger.html#a646a06d3916179b9ebc4502bad169eec',1,'Ranger::getMinRange()'],['../class_ranger_interface.html#ae6d501ddeeaad4a7b44d7d51ce64cb88',1,'RangerInterface::getMinRange()']]],
  ['getnumberofsample_5',['getNumberOfSample',['../class_laser.html#a432155ce403cb4e20fa866a24135e155',1,'Laser']]],
  ['getrawrangedata_6',['getRawRangeData',['../class_ranger_fusion.html#a8747f12610ff7a5d91d5f20deb3b22d7',1,'RangerFusion::getRawRangeData()'],['../class_ranger_fusion_interface.html#a1b62cb3119b8c9bb0a0971c46a6f5c22',1,'RangerFusionInterface::getRawRangeData()']]],
  ['getscanningarea_7',['getScanningArea',['../class_ranger_fusion.html#a7215e5405e808b5a853984e2b70ed6ad',1,'RangerFusion::getScanningArea()'],['../class_ranger_fusion_interface.html#a65155605804376da4f67baf3c6f97f40',1,'RangerFusionInterface::getScanningArea()']]],
  ['getsensingmethod_8',['getSensingMethod',['../class_ranger.html#a47e30b7ec55adec5bb542278ccfee140',1,'Ranger::getSensingMethod()'],['../class_ranger_interface.html#aeb06b9835f2b162b81917bd27797549b',1,'RangerInterface::getSensingMethod()']]],
  ['getsensorpose_9',['getSensorPose',['../class_ranger.html#aec1e730fbf4b46b01b08f6655152fc39',1,'Ranger::getSensorPose()'],['../class_ranger_interface.html#a7f6db3f603d997ad6c5aa5c7778261f4',1,'RangerInterface::getSensorPose()']]],
  ['getside_10',['getSide',['../class_cell.html#a8369e6773b462215ea3c13d216621cb7',1,'Cell']]],
  ['getstate_11',['getState',['../class_cell.html#aba131004c3f0bade13ef1b72e5694885',1,'Cell']]],
  ['grabandfusedata_12',['grabAndFuseData',['../class_ranger_fusion.html#aa9265f72bc3572567c9cf98cf6d9f0e1',1,'RangerFusion::grabAndFuseData()'],['../class_ranger_fusion_interface.html#ada6afdab2ce6d58a1bd0134f5e2be23f',1,'RangerFusionInterface::grabAndFuseData()']]]
];
