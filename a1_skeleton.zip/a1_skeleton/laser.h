#ifndef LASER_H
#define LASER_H

#include "ranger.h"

const ranger::SensingMethod LaserMethod = ranger::POINT;

class Laser: public Ranger
{
public:
  //Default constructor - should set all sensor attributes to a default value
  Laser();
  Laser(string ModelName, double maxDistance,double  minDistance,int fieldOfView, int sensorOffset,ranger::SensingMethod SMethod, int angularRes)
{
};
  ~Laser(){};
  /**
   * @brief   The virtual function to be implemented inside the derived class
   * @return  The number of samples as an int
   */
int getNumberOfSample();

};

#endif // LASER_H
