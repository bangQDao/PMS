#ifndef SONAR_H
#define SONAR_H

#include "ranger.h"

const ranger::SensingMethod SonarMethod = ranger::CONE; /*!< Default sensing method of the sonar sensor*/

class Sonar: public Ranger
{
public:
  //Default constructor should set all sensor attributes to a default value
  Sonar();
  ~Sonar();

  int getNumberOfSample();
};

#endif // SONAR_H
