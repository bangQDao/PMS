#ifndef RANGERFUSION_H
#define RANGERFUSION_H

#include <vector>
#include "rangerfusioninterface.h"
#include "rangerinterface.h"
#include  <tgmath.h>
#include "cell.h"
#include "ranger.h"
#include <math.h>
#include <iterator>
#include <bits/stdc++.h>
#include "constant.h"
using namespace std;

class RangerFusion: public RangerFusionInterface
{
public:
    /**
    The Default constructor sets the cell centre to values within the #MAP_SIZE\n
    @sa RangerFusionInterface and @sa RangerInterface for more information
    */
  RangerFusion(std::vector<RangerInterface*> rangers);

  std::vector<vector<double>> getRawRangeData();

  void setCells(std::vector<Cell*> cells);

  vector<Cell*> getCells();

  std::vector<RangerInterface*> getRangers();

  double setCellside(double cellside);

  double getScanningArea();

  double getAngularResolution(); /* For Laser */

  vector<double> getSonarOffset();

  vector<ranger::SensorPose> getSensorPoses();

  vector<double> getLaserResponse();

  vector<ranger::SensorPose> getLaserPose();

  vector<double> getX(double x, double cellsize);

  vector<double> getY(double y, double cellsize);

  vector<cell::State> laserFusion(double xCenterCell, double yCenterCell, double cellside, vector<double>cellside_Xcoordinate, vector<double>cellside_Ycoordinate, vector<double>Ranger, vector<ranger::SensorPose> laserPosess);/* Additional function */


  vector<double> getSonarResponse();

  vector<ranger::SensorPose> getSonarPose();


  vector<cell::State> SonarFusion(double cell_centerX, double cell_centerY, double cellside );/* Additional function */


  void grabAndFuseData();


  vector<vector<double>> printRawData();/* Additional function */

private:
  vector<RangerInterface*> Rangers_;
  vector<vector<double>> dataRead;
  vector<Cell*> xCells;
  vector<vector<double> > rawRangeData_;
  double rawConeCovered;
  double cellSide_;
  int laserRes;
  double sonar1stOffset;
  double sonar2ndOffset;
  ranger::SensorPose sonar1stPose;
  ranger::SensorPose sonar2ndPose;
};

#endif // RANGERFUSION_H
