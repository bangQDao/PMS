#include "ranger.h"
#include <thread>
#include <unistd.h>
// Constructor for Ranger class that initialize model, min and max range to default settings
Ranger::Ranger(): ModelName("Unknown"), minDistance(0.0), maxDistance(0.0)
{

}

//<! The function that generate the raw data
std::vector<double> Ranger::generateData()
{
   long int seed = std::chrono::system_clock::now().time_since_epoch().count();
    std::default_random_engine gen(seed);
    std::normal_distribution<double> dist(rangerMean,rangerStdev);
    vector<double> dataSample(getNumberOfSample());
    for(vector<double>::iterator it = dataSample.begin(); it!=dataSample.end(); it++)
    {
        while(1)
        {
            double temp = dist(gen);
            if((temp>=minDistance) && (temp<=maxDistance))
            {
                *it = temp;
                break;
            }
        }
    }
    dataRead = dataSample;
    return dataRead;
}


unsigned int Ranger::getAngularResolution()
{
    return angularRes;
}

ranger::SensorPose Ranger::getSensorPose(void){
    return SPose;
}

unsigned int Ranger::getFieldOfView()
{
    return fieldOfView;
}

int Ranger::getAngularOffset()
{
    return sensorOffset;
}




int Ranger::getNumberOfSample()
{
    int samples = 1 + 2 * ((getFieldOfView()/2)/getAngularResolution());
    numberOfSamples = samples;
    return numberOfSamples;
}

bool Ranger::setAngularResolution(unsigned int resolution)
{
    if((angularRes=resolution)&&
            ((angularRes==minAngle)||(angularRes==maxAngle)))
        return true;
    else
    {
        angularRes = angularResDef;
        return false;
    }
}

bool Ranger::setAngularOffset(int offset)
{
    if((sensorOffset=offset)&&(sensorOffset>=offsetMin)&&(sensorOffset<=offsetMax))
        return true;
    else
    {
        sensorOffset=angleOffsetDef;
        return false;
    }
}
bool Ranger:: setSensorPose(ranger::SensorPose pose){
    SPose = pose;
    return true;
}

bool Ranger::setFieldOfView(unsigned int fov)
{
    fieldOfView = fov;
    return true;
}


std::string Ranger::getModel()
{
    return ModelName;
}


double Ranger::getMaxRange(void)
{
    return maxDistance;
}


double Ranger::getMinRange(void)
{
    return minDistance;
}

void Ranger::pause()
{
    sleep(1);
}

ranger::SensingMethod Ranger::getSensingMethod(void)
{
    return ranger::SensingMethod();
}


