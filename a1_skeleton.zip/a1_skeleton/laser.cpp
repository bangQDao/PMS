#include"laser.h"
Laser::Laser()
{
ModelName= (LaserModel);
maxDistance = (LaserMaxDistance);
minDistance = (LaserMinDistance);
fieldOfView = (LaserFieldOfView);
sensorOffset= (0);
SMethod = (ranger::POINT);
angularRes = (LaserAngularResolutionMin);
}
int Laser::getNumberOfSample()
{
    int samples = 1 + 2 * ((getFieldOfView()/2)/getAngularResolution());
    numberOfSamples = samples;
    return numberOfSamples;
}
