#include "rangerfusioninterface.h"

RangerFusionInterface::RangerFusionInterface()
{

}
