#include <iostream>
#include <limits>
#include "laser.h"
#include "ranger.h"
#include "sonar.h"
#include "rangerfusion.h"

#include <set>

using namespace std;

int main()
{
    system("clear");
    Laser laser;
    Sonar sonar1st;
    Sonar sonar2nd;
    int counter = 0;
    int resolution = 10;
    double  laserOffset, sonar1stOffset, sonar2ndOffset, laserXpos, laserYpos, sonar1stX, sonar1stY, sonar2ndX, sonar2ndY;
    int numberOfCell;
    double cellside;
    double x, y;
    std::vector<Cell*> cells;
    Cell cell;
    cout<<"Enter Laser Resolution:"<<endl;
    cin>>resolution;
    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');


    if(laser.setAngularResolution(resolution)) cout<<"Your laser is set to "<<resolution<<" degrees angular resolution."<<endl;
    else cout<<"Invalid input value, laser resolution is 10 by default."<<endl;


    cout<<"Enter Laser Offset: "<<endl;
    cin>>laserOffset;
    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    cout<<"laser X: "<<endl;
    cin>>laserXpos;
    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    cout<<"laser Y: "<<endl;
    cin>>laserYpos;
    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    laser.setAngularResolution(resolution);
    laser.setSensorPose({laserXpos,laserYpos,laserOffset});

    cout<<"Laser Specifications:"<<endl;
    cout<<"Laser X :"<<laser.getSensorPose().x<<endl;
    cout<<"Laser Y : "<<laser.getSensorPose().y<<endl;
    cout<<"Laser offset:  "<<laser.getSensorPose().theta<<" degrees"<<endl;
    cout<<"Laser Model: "<<laser.getModel()<<endl;
    cout<<"Laser Field of view: "<<laser.getFieldOfView()<<" degrees"<<endl;
    cout<<"Laser Maximum distance: "<<laser.getMaxRange()<<"m"<<endl;
    cout<<"Laser Minimum distance: "<<laser.getMinRange()<<"m"<<endl;
    cout<<"Laser Angular resolution: " << laser.getAngularResolution() << " degree" << endl;

    cout<<"Please insert offset for first sonar: "<<endl;
    cout<<"First sonar offset: "<<endl;
    cin>>sonar1stOffset;
    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    cout<<"First sonar X coordinate: "<<endl;
    cin>>sonar1stX;
    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    cout<<"First sonar Y coordinate: "<<endl;
    cin>>sonar1stY;
    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    sonar1st.setAngularResolution(0);
    sonar1st.setSensorPose({sonar1stX,sonar1stY,sonar1stOffset});

    cout<<"First sonar specifications:"<<endl;
    cout<<"First sonar X :"<<sonar1st.getSensorPose().x<<endl;
    cout<<"First sonar Y : "<<sonar1st.getSensorPose().y<<endl;
    cout<<"First sonar Offset:  "<<sonar1st.getSensorPose().theta<<" degrees"<<endl;
    cout<<"First sonar Model: "<<sonar1st.getModel()<<endl;
    cout<<"First sonar Field of view: "<<sonar1st.getFieldOfView()<<" degrees"<<endl;
    cout<<"First sonar Maximum distance: "<<sonar1st.getMaxRange()<<"m"<<endl;
    cout<<"First sonar Minimum distance: "<<sonar1st.getMinRange()<<"m"<<endl;
    cout<<"First sonar Angular Offset: " <<sonar1st.getAngularOffset() << " degree"<<endl;

    cout<<"Enter second Sonar"<<endl;

    cout<<"Second sonar offset: "<<endl;
    cin>>sonar2ndOffset;
    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    cout<<"Second sonar  X: "<<endl;
    cin>>sonar2ndX;
    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    cout<<"Second sonar  Y: "<<endl;
    cin>>sonar2ndY;
    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    sonar1st.setAngularResolution(0);
    sonar1st.setSensorPose({sonar2ndX,sonar2ndY,sonar2ndOffset});

    cout<<"Second sonar specifications:"<<endl;
    cout<<"Second sonar X :"<<sonar2nd.getSensorPose().x<<endl;
    cout<<"Second sonar Y : "<<sonar2nd.getSensorPose().y<<endl;
    cout<<"Second sonar offset:  "<<sonar2nd.getSensorPose().theta<<" degrees"<<endl;
    cout<<"Second sonar Model: "<<sonar2nd.getModel()<<endl;
    cout<<"Second sonar Field of view: "<<sonar2nd.getFieldOfView()<<" degrees"<<endl;
    cout<<"Second sonar Maximum distance: "<<sonar2nd.getMaxRange()<<"m"<<endl;
    cout<<"Second sonar Minimum distance: "<<sonar2nd.getMinRange()<<"m"<<endl;
    cout<<"Second sonar Angular Offset: " <<sonar2nd.getAngularOffset() << " degree"<<endl;

    do
    {
        std::cout << "Enter number of Cell: " ;
        std::cin >> numberOfCell;
    } while(numberOfCell < 0);

    do
    {
        std::cout << "Enter Cell dimension : " ;
        std::cin >> cellside;
        cell.setSide(cellside);
    } while(cellside < 0);

    for(int i = 0; i < numberOfCell; i++)
    {
        cells.push_back(new Cell());
    }

    vector<vector<double>> data;
    double area_data;
    vector<RangerInterface*> vec_ragners;
    vec_ragners.push_back(&laser);
    vec_ragners.push_back(&sonar1st);
    vec_ragners.push_back(&sonar2nd);
    RangerFusion rangerfusion(vec_ragners);
    rangerfusion.setCells(cells);
    cell.setSide(cellside);
    rangerfusion.setCellside(cellside);

    system("clear");
    cout<<"Press Enter"<<endl;
    cin.ignore();
    getchar();

    while(1)
       {
           counter+=1;
           int U = 0, F = 0, O = 0;
           cout<<"Data #"<<counter<<endl;
           rangerfusion.grabAndFuseData();
           cout<<"Raw Data:"<<endl;
           data = rangerfusion.printRawData();
           for (int i = 0; i < data.size(); i++)
           {
               for (int j = 0; j < data[i].size(); j++)
                   cout << data[i][j] << " ";
               cout << endl;
           }

           cout << "Scanning area by sonar(m2): " << rangerfusion.getScanningArea() << endl;

           std::cout << "Cell State:" << endl;

           for (auto k = cells.begin();k != cells.end(); k++ ) //Return the state for each cell
           {
               cout << (*k)->getState() << " ";
               if((*k)->getState()==0)
               {
                   U++;
               }
               if((*k)->getState()==1)
               {
                   F++;
               }
               if((*k)->getState()==-1)
               {
                   O++;
               }
           }
           cout<< endl <<"UNKNOWN = " << U << endl;
           cout<<"FREE = " << F << endl;
           cout<< "OCCUPIED = " << O << endl;
           cout<<" End Scan"<<endl;
           cout << endl;
           laser.pause();
       }

       return 0;
    }



