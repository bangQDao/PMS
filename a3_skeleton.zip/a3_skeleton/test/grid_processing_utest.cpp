#include <gtest/gtest.h>
#include <climits>

//This tool allows to identify the path of the package on your system
#include <ros/package.h>

//These allow us to inspect bags of data
#include <rosbag/bag.h>
#include <rosbag/view.h>

//These allow us to make neccessary calculations
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>

//We include our header file
#include "../src/grid_processing.h"

//==================== HELPER FUNCTIONS ====================//
void printCells(nav_msgs::OccupancyGrid grid) {
  for (unsigned int row=0;row<grid.info.height-1;row++){
    for (unsigned int col=0;col<grid.info.width-1;col++){
      unsigned int index=(row*grid.info.height)+col;
      std::cout << static_cast<int>(grid.data.at(index)) << " ";
    }
    std::cout << std::endl;
  }
}
geometry_msgs::Point toLocalPoint(geometry_msgs::Point pose, geometry_msgs::Point toOri)
{
  geometry_msgs::Point local;
  local.x = pose.x - toOri.x;
  local.y = pose.y - toOri.y;
  return local;
}
double obtainYaw(geometry_msgs::Pose target)
{
  tf2::Quaternion q;
  tf2::fromMsg(target.orientation, q);
  tf2::Matrix3x3 m(q);
  double roll, pitch, yaw;
  m.getRPY(roll, pitch, yaw);
  return yaw;
}
//==================== HELPER FUNCTIONS ====================//

//! Test connection between robot_0 and robot_1
TEST(LoadedOgMap1,ConnectionTest){

  //! Below command allows to find the folder belonging to a package (a3_skeleton is the package name not the folder name)
  std::string path = ros::package::getPath("a3_skeleton");
  //! Now we have the path, the images for our testing are stored in a subfolder /test/samples
  path += "/test/samples/";
  //! The file is called smiley.bag
  std::string file = path + "LoS_true.bag";

  //! Manipulating rosbag, from: http://wiki.ros.org/rosbag/Code%20API
  rosbag::Bag bag;
  bag.open(file);  // BagMode is Read by default

  nav_msgs::OccupancyGrid::ConstPtr grid;//We need to have a pointer to extract the grid
  nav_msgs::Odometry::ConstPtr robot_0, robot_1;

  for(rosbag::MessageInstance const m: rosbag::View(bag))
  {
    if(m.getTopic() == "/local_map/local_map"){
      grid = m.instantiate<nav_msgs::OccupancyGrid>();
    }
    if(m.getTopic() == "/robot_0/odom"){
      robot_0 = m.instantiate<nav_msgs::Odometry>();
    }
    if(m.getTopic() == "/robot_1/odom"){
      robot_1 = m.instantiate<nav_msgs::Odometry>();
    }
    if (grid != nullptr && robot_0 != nullptr && robot_1 != nullptr){
      // Now we have all the data to proceed
      break;
    }
  }

  bag.close();

  ASSERT_NE(grid, nullptr);//Check that we have a grid from the bag
  ASSERT_NE(robot_0, nullptr);
  ASSERT_NE(robot_1, nullptr);

  GridProcessing gridProcessing(*grid);
  geometry_msgs::Point r0_odom = robot_0->pose.pose.position;
  geometry_msgs::Point r1_odom = robot_1->pose.pose.position;
  geometry_msgs::Point local_r1;
  local_r1.x = r1_odom.x - r0_odom.x + 0.15; 
  local_r1.y = r1_odom.y - r0_odom.y - 0.15; 
  geometry_msgs::Point zero;
  zero.x = 0;
  zero.y = 0;
  ASSERT_TRUE(gridProcessing.checkConnectivity(local_r1,zero));
}

//! Test connection between robot_0 and robot_1
TEST(LoadedOgMap2,ConnectionTest){

  //! Below command allows to find the folder belonging to a package (a3_skeleton is the package name not the folder name)
  std::string path = ros::package::getPath("a3_skeleton");
  //! Now we have the path, the images for our testing are stored in a subfolder /test/samples
  path += "/test/samples/";
  //! The file is called smiley.bag
  std::string file = path + "LoS_false.bag";

  //! Manipulating rosbag, from: http://wiki.ros.org/rosbag/Code%20API
  rosbag::Bag bag;
  bag.open(file);  

  nav_msgs::OccupancyGrid::ConstPtr grid;
  nav_msgs::Odometry::ConstPtr robot_0, robot_1;

  for(rosbag::MessageInstance const m: rosbag::View(bag))
  {
    if(m.getTopic() == "/local_map/local_map"){
      grid = m.instantiate<nav_msgs::OccupancyGrid>();
    }
    if(m.getTopic() == "/robot_0/odom"){
      robot_0 = m.instantiate<nav_msgs::Odometry>();
    }
    if(m.getTopic() == "/robot_1/odom"){
      robot_1 = m.instantiate<nav_msgs::Odometry>();
    }
    if (grid != nullptr && robot_0 != nullptr && robot_1 != nullptr){
    
      break;
    }
  }

  bag.close();

  ASSERT_NE(grid, nullptr);
  ASSERT_NE(robot_0, nullptr);
  ASSERT_NE(robot_1, nullptr);

  GridProcessing gridProcessing(*grid);
  geometry_msgs::Point r0_odom = robot_0->pose.pose.position;
 
  geometry_msgs::Point r1_odom = robot_1->pose.pose.position;
  
  geometry_msgs::Point local_r1;
  local_r1.x = r1_odom.x - r0_odom.x - 0.1; 
  local_r1.y = r1_odom.y - r0_odom.y - 0.1; 
  
  geometry_msgs::Point zero;
  zero.x = 0;
  zero.y = 0;
  
  ASSERT_FALSE(gridProcessing.checkConnectivity(local_r1,zero));
}

//! Test connectivity of published path
TEST(Path,ConnectionTest){

  //! Below command allows to find the folder belonging to a package (a3_skeleton is the package name not the folder name)
  std::string path = ros::package::getPath("a3_skeleton");
  //! Now we have the path, the images for our testing are stored in a subfolder /test/samples
  path += "/test/samples/";
  //! The file is called smiley.bag
  std::string file = path + "ogMap2.bag";

  //! Manipulating rosbag, from: http://wiki.ros.org/rosbag/Code%20API
  rosbag::Bag bag;
  bag.open(file);  
  nav_msgs::OccupancyGrid::ConstPtr grid;
  nav_msgs::Odometry::ConstPtr robot_0, robot_1;

  for(rosbag::MessageInstance const m: rosbag::View(bag))
  {
    if(m.getTopic() == "/local_map/local_map"){
      grid = m.instantiate<nav_msgs::OccupancyGrid>();
    }
    if (grid != nullptr){
    
      break;
    }
  }

  bag.close();

  ASSERT_NE(grid, nullptr);

  GridProcessing gridProcessing(*grid);
  geometry_msgs::Point toOri;
  toOri.x = 7.16961;
  toOri.y = -0.899936;

  std::vector<geometry_msgs::Point> path_robot0;

  path = ros::package::getPath("a3_skeleton");
  //! Now we have the path, the images for our testing are stored in a subfolder /test/samples
  path += "/test/samples/";
  //! The file is called smiley.bag
  file = path + "path2.bag";

  rosbag::Bag bag2;
  bag2.open(file); 
  for(rosbag::MessageInstance const m: rosbag::View(bag2))
  {
    if(m.getTopic() == "/robot_0/odom"){
      robot_0 = m.instantiate<nav_msgs::Odometry>();
      if (robot_0 != nullptr){
        path_robot0.push_back(robot_0->pose.pose.position);
      }
    }
  }

  bag2.close();

  for (int i=0; i<900; i+=10) {
    ASSERT_TRUE(gridProcessing.checkConnectivity(toLocalPoint(path_robot0.at(i),toOri),toLocalPoint(path_robot0.at(i+10),toOri)));
  }
}

//! Test robot_0 stopping behind OR on the sides of robot_1
TEST(Path,ParkingTest){

  //! Below command allows to find the folder belonging to a package (a3_skeleton is the package name not the folder name)
  std::string path = ros::package::getPath("a3_skeleton");
  //! Now we have the path, the images for our testing are stored in a subfolder /test/samples
  path += "/test/samples/";
  //! The file is called smiley.bag
  std::string file = path + "parking_ogMap.bag";

  //! Manipulating rosbag, from: http://wiki.ros.org/rosbag/Code%20API
  rosbag::Bag bag;
  bag.open(file);  

  nav_msgs::OccupancyGrid::ConstPtr grid;
  nav_msgs::Odometry::ConstPtr robot_0, robot_1;
  geometry_msgs::Point toOri;

  for(rosbag::MessageInstance const m: rosbag::View(bag))
  {
    if(m.getTopic() == "/local_map/local_map"){
      grid = m.instantiate<nav_msgs::OccupancyGrid>();
    }
    if(m.getTopic() == "/robot_0/odom"){
      robot_0 = m.instantiate<nav_msgs::Odometry>();
      if (robot_0 != nullptr){
        toOri.x = robot_0->pose.pose.position.x;
        toOri.y = robot_0->pose.pose.position.y;
        
      }
    }
  }
  std::cout << origin.x << ' ' << origin.y << std::endl;
  bag.close();
  ASSERT_NE(grid, nullptr);
  GridProcessing gridProcessing(*grid);
  std::vector<geometry_msgs::Pose> path_robot0, path_robot1;
  path = ros::package::getPath("a3_skeleton");
  //! Now we have the path, the images for our testing are stored in a subfolder /test/samples
  path += "/test/samples/";
  file = path + "parking_path.bag";
  rosbag::Bag bag2;
  bag2.open(file);  
  for(rosbag::MessageInstance const m: rosbag::View(bag2))
  {
    if(m.getTopic() == "/robot_0/odom"){
      robot_0 = m.instantiate<nav_msgs::Odometry>();
      if (robot_0 != nullptr){
        path_robot0.push_back(robot_0->pose.pose);
      
      }
    }
    if(m.getTopic() == "/robot_1/odom"){
      robot_1 = m.instantiate<nav_msgs::Odometry>();
      if (robot_1 != nullptr){
        path_robot1.push_back(robot_1->pose.pose);
      
      }
    }
  }
  bag2.close();
  //! Check for continuos connectivity
  for (int i=0; i<290; i+=10) {
    ASSERT_TRUE(gridProcessing.checkConnectivity(toLocalPoint(path_robot0.at(i).position,toOri),toLocalPoint(path_robot0.at(i+10).position,toOri)));
  }
  //! Check for final parking pose is on the side and facing robot_1 position
  std::cout << abs(obtainYaw(path_robot1.back())-obtainYaw(path_robot0.back())) << std::endl;
  ASSERT_NEAR(obtainYaw(path_robot0.back()),obtainYaw(path_robot1.back()),0.1);
  
  ASSERT_NEAR(path_robot0.back().position.x, path_robot1.back().position.x + 0.6*cos((obtainYaw(path_robot1.back()) + M_PI / 2)),0.1);
  ASSERT_NEAR(path_robot0.back().position.y, path_robot1.back().position.y + 0.6*sin((obtainYaw(path_robot1.back()) + M_PI / 2)),0.1);
}

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}