#include "sample.h"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <deque>
using namespace std;
/**
   This sample code is provided to illustrate
   - Subscribing to topics (
   - Respond to an incoming service call
   - Running a seperate thread
*/
double obtainYaw(geometry_msgs::Pose target);
double gap(double x, double y);
geometry_msgs::Point Point2Local(geometry_msgs::Pose pose, geometry_msgs::Pose origin);
Sample::Sample(ros::NodeHandle nh)
  : nh_(nh)
{
  //Example of subscribing to odometry
  sub1_ = nh_.subscribe("robot_0/odom", 1000, &Sample::odomCallback, this);
  //Subscribing to laser
  sub2_ = nh_.subscribe("robot_0/base_scan", 10, &Sample::laserCallback, this);
  //Subscribing to occupnacy grid
  sub3_ = nh_.subscribe("local_map/local_map", 1, &Sample::occupancyGridCallback, this);
  //Subscribing to robot 1 Position
  sub4_ = nh_.subscribe("robot_1/odom", 1000, &Sample::targetCallback, this);


  //Example of publishing, we publish markers here
  path_ = nh_.advertise<geometry_msgs::PoseArray>("robot_0/path", 1, false);
  following_ = nh_.advertise<visualization_msgs::MarkerArray>("robot_0/following", 3, false);
  viz_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("visualization_marker", 3, false);

  // Below is how to get parameters from command line, on command line they need to be _param:=value
  // For example _example:=0.1
  // ROS will obtain the configuration from command line, or assign a default value 0.1
  ros::NodeHandle pn("~");
  double example;
  pn.param<double>("example", example, 0.1);
  //ROS_INFO_STREAM("example:" << example);

  exampleBool_ = false; // We will use this atomic bool to let us know when we have new data

  // STUDENTS !!! - change below to be consistent with your project specification
  //Allowing an incoming service via name: /my_service_name, and calling myExample function
  service_ = nh_.advertiseService("my_service_name", &Sample::myExample, this);

}

Sample::~Sample()
{

}

//! Change this depending on your service for the project, here we use FaceGoal (which is not used
//! in any of the projects, check the request and responce fields
bool Sample::myExample(project_setup::FaceGoal::Request  &req,
                       project_setup::FaceGoal::Response &res)
{
  //When an incoming call arrives, we can respond to it here
  ROS_INFO_STREAM("request: [x,y]=[" << req.pose.x << "," << req.pose.y << "]");


  return true; //We ALWAYS return true indicate the service call sucseeded
}

// A callback for odometry
void Sample::odomCallback(const nav_msgs::OdometryConstPtr& msg)
{
  // We store a copy of the pose and lock a mutex when updating
  std::unique_lock<std::mutex> lck (poseDataBuffer_.mtx);
  poseDataBuffer_.pose = msg->pose.pose;

}
// A callback for robot_1 Position
void Sample::targetCallback(const nav_msgs::OdometryConstPtr& msg)
{
  // We store a copy of the pose and lock a mutex when updating
  std::unique_lock<std::mutex> lck (target_poseDataBuffer_.mtx);
  target_poseDataBuffer_.pose = msg->pose.pose;

}


void Sample::occupancyGridCallback(const nav_msgs::OccupancyGridPtr& msg)
{

  std::unique_lock<std::mutex> lck (ogMapBuffer_.mtx);
  ogMapBuffer_.grid = *msg;

}

void Sample::laserCallback(const sensor_msgs::LaserScanConstPtr& msg)
{
  // Not doign anything here for now
}


void Sample::seperateThread() {

  ros::Duration(2.0).sleep();

  /**
      The below loop runs until ros is shutdown
  */
  bool reached_checkPoint = true;
  tf2::Quaternion quant;
  geometry_msgs::PoseArray pose_array;
  geometry_msgs::PoseArray pose_array_stationary;
  bool modeChange = false;
  std::unique_lock<std::mutex> lck2 (poseDataBuffer_.mtx);
  geometry_msgs::Pose pose = poseDataBuffer_.pose;
  lck2.unlock();

  std::unique_lock<std::mutex> lck3 (target_poseDataBuffer_.mtx);
  geometry_msgs::Pose target = target_poseDataBuffer_.pose;
  lck3.unlock();

  geometry_msgs::Point localTarget_going;
  geometry_msgs::Point localTarget_next;
  geometry_msgs::Point localTarget_Stationary;
  localTarget_going.x = target.position.x - pose.position.x;
  localTarget_going.y = target.position.y - pose.position.y;
  bool move_toSide_once = false;
  bool changeMode = true;
  geometry_msgs::Pose checkPoint_Reached = pose;
  geometry_msgs::Pose checkPoint_last;
  geometry_msgs::Pose checkPoint_Calibrated;
  geometry_msgs::Pose checkPoint_BeforeStation;
 
  geometry_msgs::Pose prevTarget = target;
  int mode = 1;
  double timeMarkStationary;
  int StationaryStage;
  double timeStopped;
  geometry_msgs::Point zero;
  zero.x = 0;
  zero.y = 0;
  deque<geometry_msgs:: Pose> deque1;
  //deque1.push_back(offsetTarget(target,pose));
  deque1.push_back(pose);
  //! For example, let's run the thread at x Hz
  ros::Rate rate_limiter(1);
  while (ros::ok()) {
    cout<< mode << endl;
    //For example, let's get the Grid
    std::unique_lock<std::mutex> lck1 (ogMapBuffer_.mtx);
    nav_msgs::OccupancyGrid grid = ogMapBuffer_.grid;
    // We plan to use an object of our class here
    GridProcessing gridProcessing(grid);
    lck1.unlock();
    //For example, let's get Odo
    std::unique_lock<std::mutex> lck2 (poseDataBuffer_.mtx);
    geometry_msgs::Pose pose = poseDataBuffer_.pose;
    lck2.unlock();

    std::unique_lock<std::mutex> lck3 (target_poseDataBuffer_.mtx);
    geometry_msgs::Pose target = target_poseDataBuffer_.pose;
    lck3.unlock();
    checkPoint_last = deque1.back();
    localTarget_going.x = checkPoint_Reached.position.x - pose.position.x;
    localTarget_going.y = checkPoint_Reached.position.y - pose.position.y;
    if(mode == 4){
      localTarget_going.x = 0.1;
    localTarget_going.y = 0.1;
    }
   
    if (abs(checkPoint_last.position.x - target.position.x) > 0.3 || abs(checkPoint_last.position.y - target.position.y) > 0.3) {
      localTarget_next.x = target.position.x - checkPoint_last.position.x;
      localTarget_next.y = target.position.y - checkPoint_last.position.y;
      if (gridProcessing.checkConnectivity(zero, localTarget_next)) {
        double ang = atan2(localTarget_next.y, localTarget_next.x);
        quant.setRPY(0, 0, ang);
        checkPoint_Calibrated = target;
        checkPoint_Calibrated.orientation = tf2::toMsg(quant);
        deque1.push_back(checkPoint_Calibrated);
        ROS_INFO("Target reachable");
        StationaryStage = 0;
        
        if (modeChange) {
          mode = 1;
          bool move_toSide_once = false;
        }
      }
      else {
        ROS_INFO("Target not reachable");

      }
    }
    if (abs(checkPoint_last.position.x - target.position.x) <= 0.3 && abs(checkPoint_last.position.y - target.position.y) <= 0.3 && StationaryStage == 0) {
      timeMarkStationary = ros::Time::now().toSec();
      StationaryStage = 1;
      cout << "time make" << endl;
    }
    if(deque1.size() < 2){
    if(abs(prevTarget.position.x-target.position.x) < 0.1 && abs(prevTarget.position.y-target.position.y) < 0.1){
      mode = 2;
    }
    else {
      mode = 1;
      prevTarget = target;
    }
    }
    if (mode == 1) {
      move_toSide_once = false;
      cout << abs(localTarget_going.x) << " " << abs(localTarget_going.y) << " local" << endl;
      if (!reached_checkPoint && abs(localTarget_going.x) < 0.4 && abs(localTarget_going.y) < 0.4) {
        ROS_INFO("Target reached!");
        reached_checkPoint = true;
        cout << "not reach" << endl;
      }
      if (reached_checkPoint) {
        cout << "each" << endl;
        pose_array.poses.push_back(deque1.front());
        checkPoint_Reached = deque1.front();
        ROS_INFO("Pose_Array published");
        reached_checkPoint = false;
        path_.publish(pose_array);
        pose_array.poses.clear();
        deque1.pop_front();
        if (deque1.size() == 0) {
          deque1.push_front(checkPoint_Reached);
          checkPoint_BeforeStation = deque1.front();
          mode = 2;
          modeChange = false;
        }
      }
    }
    if (mode == 2) {
      timeStopped = ros::Time::now().toSec() - timeMarkStationary;
      if (timeStopped <= 10) mode = 3;
      if (timeStopped > 10) mode = 4;
      modeChange = true;
    }
    if (mode == 3 && modeChange ) {
      modeChange = false;
      double Yaw = obtainYaw(target);
      geometry_msgs::Pose behindPos = target;
      behindPos.position.x -= 0.7 * cos(Yaw);
      behindPos.position.y -= 0.7 * sin(Yaw);
      localTarget_Stationary.x =  pose.position.x - behindPos.position.x;
      localTarget_Stationary.y = pose.position.y - behindPos.position.y;
      pose_array.poses.push_back(behindPos);
      path_.publish(pose_array);
      pose_array.poses.clear();
      if (gap(localTarget_Stationary.x, localTarget_Stationary.y) < 1.5) {
        modeChange = true;
        if (ros::Time::now().toSec() - timeMarkStationary > 10) mode = 4;
      }
    }
    if (mode == 4 && modeChange ) {
      modeChange = false;
      if (!move_toSide_once) {
        double Yaw = obtainYaw(target);
        geometry_msgs::Pose leftSidePos, rightSidePos;
        for (auto i = 0; i < 1; i++)
        {
          leftSidePos = target;
          leftSidePos.position.x += 0.8 * cos((Yaw + M_PI * 3 / 4));
          leftSidePos.position.y += 0.8 * sin((Yaw + M_PI * 3 / 4));
          if (!gridProcessing.checkConnectivity(Point2Local(leftSidePos, pose), zero)) break;
          pose_array_stationary.poses.push_back(leftSidePos);
          leftSidePos = target;
          leftSidePos.position.x += 0.6 * cos((Yaw + M_PI / 2));
          leftSidePos.position.y += 0.6 * sin((Yaw + M_PI / 2));
          if (!gridProcessing.checkConnectivity(Point2Local(leftSidePos, pose), zero)) {
            pose_array_stationary.poses.clear();
            break;
          }
          pose_array_stationary.poses.push_back(leftSidePos);
          path_.publish(pose_array_stationary);
          pose_array_stationary.poses.clear();

          move_toSide_once = true;
        }
        if (!move_toSide_once) {
          for (auto i = 0; i < 1; i++)
          {
            rightSidePos = target;
            rightSidePos.position.x += 0.8 * cos((Yaw - M_PI * 3 / 4));
            rightSidePos.position.y += 0.8 * sin((Yaw - M_PI * 3 / 4));
            if (!gridProcessing.checkConnectivity(Point2Local(rightSidePos, pose), zero)) break;
            pose_array_stationary.poses.push_back(rightSidePos);
            rightSidePos = target;
            rightSidePos.position.x += 0.6 * cos((Yaw - M_PI / 2));
            rightSidePos.position.y += 0.6 * sin((Yaw - M_PI / 2));
            if (!gridProcessing.checkConnectivity(Point2Local(rightSidePos, pose), zero)) {
              pose_array_stationary.poses.clear();
              break;
            }
            pose_array_stationary.poses.push_back(rightSidePos);
            path_.publish(pose_array_stationary);
            pose_array_stationary.poses.clear();
            move_toSide_once = true;
          }
        }
      }
      modeChange = true;
     
    }
    rate_limiter.sleep();
  }
}
double obtainYaw(geometry_msgs::Pose target) {
  tf2::Quaternion quant;
  tf2::fromMsg(target.orientation, quant);
  tf2::Matrix3x3 m(quant);
  double Roll, Pitch, Yaw;
  m.getRPY(Roll, Pitch, Yaw);
  return Yaw;
}
double gap(double x, double y) {
  double i;
  i = sqrt(pow(x, 2) + pow(y, 2));
  return i;
}
visualization_msgs::Marker Sample::produceMarkerSphere(geometry_msgs::Point point,
    std_msgs::ColorRGBA color,
    int& id ) {

  visualization_msgs::Marker marker;

  //We need to set the frame
  // Set the frame ID and time stamp.
  marker.header.frame_id = "world";
  //single_marker_person.header.stamp = ros::Time();
  marker.header.stamp = ros::Time::now();


  //We set lifetime (it will dissapear in this many seconds)
  marker.lifetime = ros::Duration(10.0);
  // Set the namespace and id for this marker.  This serves to create a unique ID
  // Any marker sent with the same namespace and id will overwrite the old one
  marker.ns = "test";
  marker.id = id++;

  // The marker type, we use a cylinder in this example
  marker.type = visualization_msgs::Marker::CYLINDER;

  // Set the marker action.  Options are ADD and DELETE (we ADD it to the screen)
  marker.action = visualization_msgs::Marker::ADD;

  marker.pose.position.x = point.x;
  marker.pose.position.y = point.y;
  marker.pose.position.z = 0.0;

  //Orientation, we are going to leave it as 0,0,0,1 for quaternion,
  //For an arrow you copudl consider passing yaw or quaternion for it
  marker.pose.orientation.x = 0.0;
  marker.pose.orientation.y = 0.0;
  marker.pose.orientation.z = 0.0;
  marker.pose.orientation.w = 1.0;

  // Set the scale of the marker -- 0.5x0.5x0.5 here means 0.5m side
  marker.scale.x = 0.5;
  marker.scale.y = 0.5;
  marker.scale.z = 0.5;

  //Alpha is stransparency (50% transparent)
  marker.color = color;

  return marker;

}
geometry_msgs::Point Point2Local(geometry_msgs::Pose pose, geometry_msgs::Pose origin) {
  geometry_msgs::Point local_point;
  local_point.x = pose.position.x - origin.position.x;
  local_point.y = pose.position.y - origin.position.y;
  local_point.z = origin.position.z;
  return local_point;
}
