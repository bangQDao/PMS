var searchData=
[
  ['checkconnectivity_12',['checkConnectivity',['../class_grid_processing.html#a630be91681416803d0a353dc04e08ae7',1,'GridProcessing::checkConnectivity(geometry_msgs::Point origin, geometry_msgs::Point destination)'],['../class_grid_processing.html#a6e9baea35649a567874c595a7f7b3f08',1,'GridProcessing::checkConnectivity(double x0, double y0, double x1, double y1)']]]
];
